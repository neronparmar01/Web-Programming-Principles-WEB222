window.products = [
 // electronics
    {
        id : "00111",
        title :"JBL Tune 230NC - True Wireless Noise Cancelling Earbuds, Up to 40 Hours of Battery Life - White",
        price :6065,
        description : "JBL airpodes for all use, advanced sound quality, battery backup for 40+ hours, noise canceling feature, 4 mics for perfect voice calls: Enjoy hassle-free, hands-free calls in stereo. The Tune 230NC TWS are equipped with 4 microphones, so you’ll always be heard with perfect clarity. Never hesitate to take or make a call again.",
        discontinued: false,
        categories : ["SNK-ELECTRONICS"]
    },

    {
        id : "00112",
        title :"Sleep Headphones Wireless, Perytong Bluetooth Sports Headband Headphones with Ultra-Thin HD Stereo Speakers Perfect for Sleeping,Workout,Jogging,Yoga,Insomnia, Air Travel, Meditation",
        price :5010,
        description : "Best wireless product for having a perfect sound sleep, truely wireless with battery backup of 45 hours, an over ear type band, comfortable with port of c cable charging.Sleep headphones bluetooth built-in 2 ultra-thin speakers, devices control module is in the middle of bluetooth sleep headband, no press the ears, 2-2.5 hours charging time only, Bluetooth headband headphones is the cool tech gifts for men/ women/ family/ teens/ friends.",
        discontinued: false,
        categories : ["SNK-ELECTRONICS"]
    },

    {
        id : "00113",
        title :"Samsung - 85 AU8000 LED 4K Ultra HD HDR Smart TV [UN85AU8000FXZC][Canada Version] (2021)",
        price :200000,
        description : "Available in all the sizes of 43, 50, 55, 65, 75, 85 inches. Has all the new and updated features with a screen of 4k resolution and UHD display. Has refresh rate of 60Hz, slim design,  can schedule recordings, search, and game, all while connecting to more devices across your home.",
        discontinued: false,
        categories : ["SNK-ELECTRONICS"]
    },

    {
        id : "00114",
        title :"2021 Dell Inspiron 7000 2-in-1",
        price :200000,
        description : "13.3 FHD Touchscreen Laptop Computer, Intel Core i5-1135G7, 8GB RAM, 512GB PCIe SSD, Backlit Keyboard, Intel Iris Xe Graphics, HD Webcam, MaxxAudio, Windows 11, Silver.Plenty of high-bandwidth RAM to smoothly run your games as well as multiple programs. 【512GB PCIe SSD】Save files fast and store more data. Ports: 1x USB Type A, 1x USB Type C, 1x Headphone jack, 1x HDMI, 1x SD card reader. Amazon Alexa Enabled.",
        discontinued: false,
        categories : ["SNK-ELECTRONICS"]
    },

    {
        id : "00114",
        title :"2021 Apple MacBook Pro (16-inch, Apple M1 Pro chip with 10‑core CPU and 16‑core GPU, 32GB RAM, 512GB SSD) - Space Gray Z14V0016E",
        price :280000,
        description : "Apple M1 Pro chip with 10‑core CPU and 16‑core GPU, with an integrated card and the graphics processor of the M1 Pro,16-core GPU with up to 4x faster performance for graphics-intensive apps and games, with the battery backup of upto 21 hours.",
        discontinued: false,
        categories : ["SNK-ELECTRONICS"]
    },
// Mens----------------------------------------------------------
    {
        id:"01123",
        title:"Adidas Mens Grand Court 2.0 Training Shoes",
        price: 12000,
        description:"A best shoe fit for Mens, stylish, comfortable, best suit for sports. A great pick up for all the athletes for better performance.",
        discontinued: false,
        categories: ["SNK-MEN'S COLLECTION"]
    },

    {
        id :"01124",
        title:"OLEVS Male Wrist Watches, Analog Quartz Business Stainless Steel Waterproof Luminous Watches Luxury Casual Classic Glamour Big Diamond Dial Date Multi-Function Chronograph Watches for Man",
        price:9575,
        description:"Perfectly designed wrist watch for Mens, A very Royalistic and classic design for every suits. Best Option to gift for your husband, son, father, friend or collegue on their birthdays or this christmas.",
        discontinued: false,
        categories:["SNK-MEN'S COLLECTION"]
    },

    {
        id :"01125",
        title:"Calvin Klein Mens Modern Fit 100% Wool Tuxedo Suit Separates - Custom Jacket & Pant Size Selection",
        price:13575,
        description:"Very classic and  casual suit wear for all type of the events for men, fixed button closure, woolen material used, esay to wash and dry clean, best suited in offices, for functions and meetings. Best grab for the choosy individuals.",
        discontinued: false,
        categories:["SNK-MEN'S COLLECTION"]
    },

    {
        id :"01126",
        title:"Timberland Mens Hood Honcho Sport Pullover",
        price:6020,
        description:"Perfectly designed for individuals perferring stylish hoodies, its a machine friendly material made, so easy to wash in machine, available in all sizes, also best option for mens for a sporty look as well.",
        discontinued: false,
        categories:["SNK-MEN'S COLLECTION"]
    },
// women-------------------------------------------------
    {
        id :"02111",
        title:"EFAN Women's Cute Hoodies Teen Girl Fall Jacket Oversized Sweatshirts Casual Drawstring Clothes Zip Up Y2K Hoodie with Pocket",
        price:4025,
        description:" Long Sleeve Women Pullover Sweatshirt/Solid Color/Lapel/Drawstring Collar/Half Zipper Sweatshirt/Kangaroo Pockets/Dropped Shoulder/Ribbed Hem And Cuffs/Loose Fit Style/Casual Tops For Women/Tunic Sweatshirts For Women, Perfectly designed for individuals perferring stylish hoodies, its a machine friendly material made, so easy to wash in machine.",
        discontinued: false,
        categories:["SNK-WOMEN'S COLLECTION"]
    },

    {
        id :"02112",
        title:"adidas Women's The Cloudfoam Pure Running Shoe",
        price:4025,
        description:"Very strechable material with comfortable to wear,Sock-like construction hugs the foot, Easy to wear and with washable material as well, best suits for running or in any kind of sport. Daily usable shoes for Womens.",
        discontinued: false,
        categories:["SNK-WOMEN'S COLLECTION"]
    },

    {
        id :"02113",
        title:"DIRASS Women's Elegant Velvet Long Sleeve Wrap V Neck Ruched Bodycon Cocktail Party Maxi Dress",
        price:6065,
        description:"A velvet used material, with a pull on closure, 95%Polyester 5%Spandex, super softcomfy and stretchy, keeps you fitted in all the right places and mold to your curve perfectly. Perfect outfit for  formal occassion, party, club, night out, dating, cocktail, wedding or daily wear.",
        discontinued: false,
        categories:["SNK-WOMEN'S COLLECTION"]
    },

    {
        id :"02114",
        title:"Kendra Scott Elisa Pendant Necklace for Women, Fashion Jewelry, 14k Gold-Plated",
        price:10399,
        description:"This necklace measures 0.63 L x 0.38 W stationary pendant, 15 chain with 2 extender.  a perfect gift for Valentine’s Day, Christmas, your wedding anniversary, Mother’s Day and birthdays. remove your jewelry prior to hand washing, swimming, exercising, cleaning, and before applying any kind personal body products. Maintain your jewelry’s high shine by avoiding contact with soap, perfume, lotion, makeup, hair & cleaning products.",
        discontinued: false,
        categories:["SNK-WOMEN'S COLLECTION"]
    },
// kids------------------------------------------------------
  
{
    id :"03111",
    title:"Baby Boys Girls Ribbed Bodysuit Outfit",
    price:2189,
    description:"A very Soft, warm, trendy and fashion solid color ribbed cotton blend unisex babies clothing. Light weight, skin friendly, breathable. Perfect fit for the age group of new born babies to one year kid. A machine friendly material.",
    discontinued: false,
    categories:["SNK-KID'S COLLECTION"]
},

{
    id :"03112",
    title:"Paw Patrol Boys' Graphic Zip-up Hoodie",
    price:999,
    description:"Material contains 60% Cotton, 40% Polyester, with a Zipper closure, easy with Machine Wash and soft cotton blend material for added comfort, Adorable, fun and bright graphics.",
    discontinued: false,
    categories:["SNK-KID'S COLLECTION"]
},

{
    id :"03113",
    title:"The Children's Place Girls Print Basic Layering Tees",
    price:856,
    description:"Everyday style for girls that pairs with her favorite jackets, pants and accessories, a crew neck, short sleeves and high low hem. With 40% polyster and 60% cotton material.          ",
    discontinued: false,
    categories:["SNK-KID'S COLLECTION"]
},

{
    id :"03114",
    title:"Vivay Kids Girls Shoes Boy Tennis Sport Running Sneakers Casual Walking Fashion Sneakers",
    price:3575,
    description:"A best option for kids with soft and comfort mesh fabric upper, keeps foot dry and cool, anti-twist,and can stand up to daily playground wear-and-tear,gives the foot maximum range in movement.",
    discontinued: false,
    categories:["SNK-KID'S COLLECTION"]
},


//Accessories---------------------------------------------------
{
    id :"04111",
    title:"Christmas String Lights Set, 120 LED 10Pcs Santa Lights, Waterproof Twinkle Light, USB Powered Christmas Hanging Ornaments for Indoor Outdoor, Xmas Tree Patio Bedroom Decor, Warm White",
    price:2575,
    description:"Very beautiful and attractive lights for enlighting your home this chritstmas, waterproof and can be used in outdoors as well as indoors, with a unique design with yellow lightning color, operated with the USB plug use of low-heat, energy-efficient LEDs ensures safe, aesthetic and continuous lighting. It has low voltage and won't overheat.",
    discontinued: false,
    categories:["SNK-ACCESSORIES"]
},

{
    id :"04112",
    title:"Alpine Corporation Alpine WHS110MC-TM Christmas Village, Multicolor",
    price:4580,
    description:"A perfect decor to decorate the house with a small piece of art, built in LED lights with mutlicolor lightings. Best decor for this christmas,Bring your decorations to life with the Dancing Ice Skaters of this winter scene that move with a flip of the on/off switch.",
    discontinued: false,
    categories:["SNK-ACCESSORIES"]
},

{
    id :"04113",
    title:"Wooden Seasonal Welcome Sign For Front Door-10 Holiday Interchangeable Icons- Round Wood Hanging Front Door Sign For Every Season - Farmhouse Wall Decor (Brown)",
    price:1999,
    description:"A Welcome board with an interchangeable icons with artificial plants, comes with 10 seasonal decorations, so you can change each accessory according to your needs, cute ornaments are made of wood material which are thicker and stronger, with no odor, safe and durable to use.",
    discontinued: false,
    categories:["SNK-ACCESSORIES"]
},


];
