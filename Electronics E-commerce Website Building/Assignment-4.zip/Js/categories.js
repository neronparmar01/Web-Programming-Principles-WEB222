
 window.categories = [
    { id: "SNK-ELECTRONICS", name: "Electronics" },
    { id: "SNK-MEN'S COLLECTION", name: "Men's Collection" },
    { id: "SNK-WOMEN'S COLLECTION", name: "Women's Collection" },
    { id: "SNK-KID'S COLLECTION", name: "Kid's Collection" },
    {id: "SNK-ACCESSORIES", name:"Accessories"}
];
  