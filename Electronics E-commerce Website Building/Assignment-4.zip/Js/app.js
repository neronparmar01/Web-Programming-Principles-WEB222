/**
 * WEB222 – Assignment 04
 * 
 *      Name:       Neron Nelson Parmar
 *      Student ID: 171690217
 *      Date:       3/12/22  
 *
 * I declare that this assignment is my own work. There were some problem i was facing in this
 * assignment and for solving, thus i had taken help of my friend and internet. As i was not
 * able to attend the class due to my medical issue, and due to that I missed some topics and 
 * had to cover up those topics with help of my friends and internet.
 *
**/


const { products, categories } = window;


let MenArr = [];
let WomenArr = [];
let ChildrenArr = [];

for (let i = 0; i < products.length; i++) {
  products[i].categories.forEach(function (element) {
    if (element === "SNK-MEN'S COLLECTION" && products[i].discontinued === false) {
      MenArr.push(products[i].description);
    } else if (element === "SNK-WOMEN'S COLLECTION" && products[i].discontinued === false) {
      WomenArr.push(products[i].description);
    } else if (element === "SNK-KID'S COLLECTION" && products[i].discontinued === false) {
      ChildrenArr.push(products[i].description);
    }
  });
}


let menu = document.getElementById("menu");
for (let i = 0; i < categories.length; i++) {
  let newMenuItem = document.createElement("button");
  newMenuItem.textContent = categories[i].name;
  newMenuItem.id = categories[i].name;
  menu.appendChild(newMenuItem);
}


function descriptionPrinter(category) {
  
  let tableRows = document.getElementsByClassName("tbl-row");
 if (category === "SNK-MEN'S COLLECTION") {
    for (let i = 0; i < MenArr.length; i++) {
      tableRows[i].addEventListener("click", function () {
        console.log(MenArr[i]);
      });
    }
  } else if (category === "SNK-WOMEN'S COLLECTION") {
    for (let i = 0; i < WomenArr.length; i++) {
      tableRows[i].addEventListener("click", function () {
        console.log(WomenArr[i]);
      });
    }
  } else if (category === "SNK-CHILDREN") {
    for (let i = 0; i < ChildrenArr.length; i++) {
      tableRows[i].addEventListener("click", function () {
        console.log(ChildrenArr[i]);
      });
    }
  }
}


function createCells(category) {
  
  var tbodyRef = document.getElementById("categoryProducts");
  var newRow, newCell, newText;

  
  for (let i = 0; i < products.length; i++) {
    
    document.createElement("tr");

    
    products[i].categories.forEach(function (element) {
      if (element === category && products[i].discontinued === false) {
        newRow = tbodyRef.insertRow();
        newRow.className = "tbl-row";

        
        newCell = newRow.insertCell();
        
        newText = document.createTextNode(products[i].title);
        newCell.appendChild(newText);

        
        newCell = newRow.insertCell();
        newCell.id = i;
        
        newText = document.createTextNode(products[i].description);
        newCell.appendChild(newText);

        
        newCell = newRow.insertCell();
        
        newText = document.createTextNode(
          (products[i].price / 100).toLocaleString("en-CA", { currency: "CAD", style: "currency" })
        ); 
        newCell.appendChild(newText);
      }
    });
  }
}



function showProductList(category) {
  
  document.getElementById("categoryProducts").innerHTML = "";

 
  for (let k = 0; k < categories.length; k++) {
    if (categories[k].name === category) {
      category = categories[k].id;
    }
  }

 
  createCells(category);
  descriptionPrinter(category);
}


let menuArr = document.querySelector("#menu").querySelectorAll("button");
for (let i = 0; i < menuArr.length; i++) {
  menuArr[i].addEventListener("click", function () {
    document.getElementById("selected-category").innerHTML = menuArr[i].textContent;
    showProductList(menuArr[i].textContent);
  });
}


